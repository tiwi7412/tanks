#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsView>
#include "game.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui_;
    QGraphicsView *view_;
    QGraphicsScene *scene_;
    QGraphicsView *view_2_;
    QGraphicsScene *scene_2_;
    QGraphicsView *view_3_;
    QGraphicsScene *scene_3_;
    QGraphicsView *view_4_;
    QGraphicsScene *scene_4_;
    Game *game_;
};
#endif // MAINWINDOW_H
