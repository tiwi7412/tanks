#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "item.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui_(new Ui::MainWindow)
{
    ui_->setupUi(this);
    view_ = ui_->plotGraphicsView;
    view_2_ = ui_ ->plotGraphicsView_2;
    view_3_ = ui_ ->ships_view;
    view_4_ = ui_ ->ships_view_2;

    scene_ = new QGraphicsScene;
    scene_2_ = new QGraphicsScene;
    scene_3_ = new QGraphicsScene;
    scene_4_ = new QGraphicsScene;
    view_->setScene(scene_);
    // make the scene the same size as the view containing it
    view_->setSceneRect(0,0,view_->frameSize().width(),view_->frameSize().height());
    view_2_->setScene(scene_2_);
    // make the scene the same size as the view containing it
    view_2_->setSceneRect(0,0,view_2_->frameSize().width(),view_2_->frameSize().height());
    view_3_->setScene(scene_3_);
    // make the scene the same size as the view containing it
    view_3_->setSceneRect(0,0,view_3_->frameSize().width(),view_3_->frameSize().height());
    view_4_->setScene(scene_4_);
    // make the scene the same size as the view containing it
    view_4_->setSceneRect(0,0,view_4_->frameSize().width(),view_4_->frameSize().height());

    for(int i = 0; i< 10; i++){
        scene_ ->addLine(0,29+i*29,view_->frameSize().width(),29+i*29);
        scene_ ->addLine(29+i*29,0,29+i*29,view_->frameSize().height());
    }
    for(int i = 0; i< 10; i++){
        scene_2_ ->addLine(0,29+i*29,view_->frameSize().width(),29+i*29);
        scene_2_ ->addLine(29+i*29,0,29+i*29,view_->frameSize().height());
    }
    std::string atoj = "ABCDEFGHIJ";
    for (int i = 1; i <=10; i++){
        QGraphicsTextItem* text = scene_->addText(QString(atoj[i-1]));
        //board[i*10+j] = new Tile(i*10+j+1);
        text->setPos(view_->frameSize().width()/11*i,0);
        //board[i*10+j]->set_x(view->frameSize().width()/10*j);
        //board[i*10+j]->set_y(view->frameSize().height()/10*(9-i));

    }
    for (int i = 1; i <=10; i++){
        QGraphicsTextItem* text = scene_2_->addText(QString(atoj[i-1]));
        //board[i*10+j] = new Tile(i*10+j+1);
        text->setPos(view_2_->frameSize().width()/11*i,0);
        //board[i*10+j]->set_x(view->frameSize().width()/10*j);
        //board[i*10+j]->set_y(view->frameSize().height()/10*(9-i));

    }
    for (int i = 1; i <=10; i++){
        QGraphicsTextItem* text = scene_->addText(QString::number(11-i));
        //board[i*10+j] = new Tile(i*10+j+1);
        text->setPos(0,view_->frameSize().height()/11*(11-i));
        //board[i*10+j]->set_x(view->frameSize().width()/10*j);
        //board[i*10+j]->set_y(view->frameSize().height()/10*(9-i));

    }
    for (int i = 1; i <=10; i++){
        QGraphicsTextItem* text = scene_2_->addText(QString::number(11-i));
        //board[i*10+j] = new Tile(i*10+j+1);
        text->setPos(0,view_2_->frameSize().height()/11*(11-i));
        //board[i*10+j]->set_x(view->frameSize().width()/10*j);
        //board[i*10+j]->set_y(view->frameSize().height()/10*(9-i));

    }
    QColor color(150,75,0);
    Item * ship_1 = new Item(color, 0, 0, 29, 87);
    Item * ship_2 = new Item(color, 39, 0, 87, 29);
    Item * ship_3 = new Item(color, 39, 39, 58, 29);
    Item * ship_4 = new Item(color, 136, 0, 29, 58);
    Item * ship_5 = new Item(color, 102, 39, 29, 29);

    QColor color_chest(255,215,0);
    Item * chest_1 = new Item(color_chest, 184, 0, 29, 29);
    Item * chest_2 = new Item(color_chest, 184, 39, 29, 29);

    QColor color_mine(0,0,0);
    Item * mine_1 = new Item(color_mine, 223, 0, 29, 29);
    Item * mine_2 = new Item(color_mine, 223, 39, 29, 29);

    // add these to the scene for player 1
    scene_3_->addItem(ship_1);
    scene_3_->addItem(ship_2);
    scene_3_->addItem(ship_3);
    scene_3_->addItem(ship_4);
    scene_3_->addItem(ship_5);
    scene_3_->addItem(chest_1);
    scene_3_->addItem(chest_2);
    scene_3_->addItem(mine_1);
    scene_3_->addItem(mine_2);

    Item * ship_6 = new Item(color, 0, 0, 29, 87);
    Item * ship_7 = new Item(color, 39, 0, 87, 29);
    Item * ship_8 = new Item(color, 39, 39, 58, 29);
    Item * ship_9 = new Item(color, 136, 0, 29, 58);
    Item * ship_10 = new Item(color, 102, 39, 29, 29);

    Item * chest_3 = new Item(color_chest, 184, 0, 29, 29);
    Item * chest_4 = new Item(color_chest, 184, 39, 29, 29);

    Item * mine_3 = new Item(color_mine, 223, 0, 29, 29);
    Item * mine_4 = new Item(color_mine, 223, 39, 29, 29);
    // add these to the scene for player 2
    scene_4_->addItem(ship_6);
    scene_4_->addItem(ship_7);
    scene_4_->addItem(ship_8);
    scene_4_->addItem(ship_9);
    scene_4_->addItem(ship_10);
    scene_4_->addItem(chest_3);
    scene_4_->addItem(chest_4);
    scene_4_->addItem(mine_3);
    scene_4_->addItem(mine_4);


    //game_ = new Game(view_,scene_,view_2_,scene_2_);
}

MainWindow::~MainWindow()
{
    delete ui_;
}

