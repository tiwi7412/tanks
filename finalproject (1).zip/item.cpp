#include <cstdlib>
#include <ctime>
#include <cmath>
#include <iostream>
#include <QtWidgets>

#include "item.h"

/**
  Creates a new Point object with coordinates x and y
  @param x int x coordinate
  @param y int y coordinate
*/
Item::Item(QColor color, const int x, const int y, int width, int height) {
  this->color_ = color;
  x_ = x;
  y_ = y;
  height_ = height;
  width_ = width;
}

//in point.cpp
void Item::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED(event);

    qDebug() << "point clicked!";

    // Day 3, Task 2, Step 1
    // emit this signal when the user right-clicks on the point
    // you can compare the event()->button value to Qt::ModifierYouAreLookingFor
    if(event->button() == Qt::RightButton){
        emit PointSelected(this);
    }

    emit DeletePoint(this);

    if(event->modifiers() == Qt::ShiftModifier){
        emit DrawLine(this);
    }

    // Day 3, Task 1
    // Change the color of the point when the user clicks on it

    // change to a new color
    int r = QRandomGenerator::global()->generate() % 256;
    int g = QRandomGenerator::global()->generate() % 256;
    int b = QRandomGenerator::global()->generate() % 256;
    QColor c(r, g, b);
    color_ = c;
    qDebug() << "(" << r << "," << g << "," << b << ")";

    // need to make the point actually re-paint itself
    update();
}

// where is this object located
// always a rectangle, Qt uses this to know "where" the user
// would be interacting with this object
QRectF Item::boundingRect() const
{
    return QRectF(x_, y_, width_, height_);
}

// define the actual shape of the object
QPainterPath Item::shape() const
{
    QPainterPath path;
    path.addRect(x_, y_, width_, height_);
    return path;
}

// called by Qt to actually display the point
void Item::paint(QPainter *painter, const QStyleOptionGraphicsItem *option, QWidget *widget)
{
    Q_UNUSED(widget);


    QBrush b = painter->brush();
    // update the line for setBrush to be this
    painter->setBrush(QBrush(color_));
    painter->drawRect(QRect(this->x_, this->y_, this->width_, this->height_));
    painter->setBrush(b);
}

